# Mohammed Adnan — Academic Website

A minimal Jekyll academic website, structured like [tomjacobs05.github.io](https://tomjacobs05.github.io/).

## Setup & Local Preview

1. Install Ruby + Bundler (if not already):
   ```bash
   gem install bundler
   ```

2. Install dependencies:
   ```bash
   bundle install
   ```

3. Run locally:
   ```bash
   bundle exec jekyll serve
   ```
   Open http://localhost:4000

## Deploy to GitHub Pages

1. Create a repo named `adnan1306.github.io` on GitHub
2. Push this folder to the `main` branch
3. Go to Settings → Pages → Source: `main` branch → Save

Your site will be live at `https://adnan1306.github.io` within a minute.

## Customising Content

| What | Where |
|------|-------|
| Your name, email, photo path, nav links | `_config.yml` |
| Bio paragraphs | `index.md` |
| Updates list | `_data/updates.yml` |
| Publications | `_data/publications.yml` |
| CV text | `cv.md` |
| Awards | `awards.md` |
| Styling | `assets/css/main.css` |

## Adding Your Photo

Drop your headshot into `assets/images/headshot.png` (or update the path in `_config.yml`).
